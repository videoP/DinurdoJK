// Full-resolution ownership gate for world-space SSR.
//
// The reflection-policy/linear-depth prepass describes static BSP surfaces.
// The real scene depth also contains later opaque depth owners (players,
// vehicles, grass/snow shells, promoted ocean, etc.).  SSR must only composite
// where the BSP surface that supplied the policy is still the frontmost owner.

@group(0) @binding(0) var scene_depth: texture_depth_2d;
@group(0) @binding(1) var prepass_depth: texture_depth_2d;

struct VertexOut {
    @builtin(position) position: vec4<f32>,
    @location(0) uv: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vertex_index: u32) -> VertexOut {
    var positions = array<vec2<f32>, 3>(
        vec2<f32>(-1.0, -3.0),
        vec2<f32>(-1.0, 1.0),
        vec2<f32>(3.0, 1.0)
    );
    let p = positions[vertex_index];
    var out: VertexOut;
    out.position = vec4<f32>(p, 0.0, 1.0);
    out.uv = vec2<f32>(p.x * 0.5 + 0.5, 0.5 - p.y * 0.5);
    return out;
}

@fragment
fn fs_main(input: VertexOut) -> @location(0) f32 {
    let dims = textureDimensions(prepass_depth);
    let dims_f = vec2<f32>(f32(dims.x), f32(dims.y));
    let maximum = vec2<i32>(i32(dims.x) - 1, i32(dims.y) - 1);
    let pixel = clamp(
        vec2<i32>(
            i32(clamp(input.uv.x, 0.0, 0.999999) * dims_f.x),
            i32(clamp(input.uv.y, 0.0, 0.999999) * dims_f.y)
        ),
        vec2<i32>(0),
        maximum
    );
    let bsp_depth = textureLoad(prepass_depth, pixel, 0);
    let final_depth = textureLoad(scene_depth, pixel, 0);

    // Reverse-Z: larger depth is closer. The static BSP should produce the same
    // depth in both passes. Any meaningfully larger final depth means a later
    // opaque surface now owns this pixel, so the cached BSP reflection policy
    // must not be applied here. A tiny epsilon only absorbs float raster noise.
    if (bsp_depth <= 0.0 || final_depth <= 0.0 || final_depth > bsp_depth + 1.0e-7) {
        return 0.0;
    }
    return 1.0;
}
