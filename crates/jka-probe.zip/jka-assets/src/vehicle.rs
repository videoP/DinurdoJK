//! Vehicle presentation metadata from JKA `ext_data/vehicles/*.veh` files.
//!
//! Multiplayer does not send a vehicle's Ghoul2 qpath directly. The server can
//! put the vehicle definition name in `CS_MODELS`/`modelindex`; OpenJK then
//! resolves that definition's `model` (and optional `skin`) before registering
//! `models/players/<model>/model.glm`.

use std::collections::BTreeMap;

use crate::pk3::AssetSearchPath;

const VEHICLE_DIRECTORY: &str = "ext_data/vehicles/";
const VEHICLE_EXTENSION: &str = ".veh";
const MAX_VEHICLE_FILE_SIZE: usize = 4 * 1024 * 1024;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VehicleDefinition {
    pub name: String,
    pub model: String,
    pub skin: Option<String>,
}

#[derive(Debug, Clone, Default)]
pub struct VehicleDefinitions {
    definitions: BTreeMap<String, VehicleDefinition>,
}

impl VehicleDefinitions {
    pub fn get(&self, name: &str) -> Option<&VehicleDefinition> {
        self.definitions.get(&name.to_ascii_lowercase())
    }

    pub fn len(&self) -> usize {
        self.definitions.len()
    }
}

pub fn load_vehicle_definitions(assets: &mut AssetSearchPath) -> Result<VehicleDefinitions, String> {
    let names = assets
        .names()
        .filter(|name| name.starts_with(VEHICLE_DIRECTORY) && name.ends_with(VEHICLE_EXTENSION))
        .map(str::to_owned)
        .collect::<Vec<_>>();

    let mut definitions = BTreeMap::new();
    for name in names {
        let Some(asset) = assets
            .read(&name, MAX_VEHICLE_FILE_SIZE)
            .map_err(|error| format!("{name}: {error}"))?
        else {
            continue;
        };
        parse_vehicle_file(&asset.bytes, &mut definitions)
            .map_err(|error| format!("{name}: {error}"))?;
    }
    Ok(VehicleDefinitions { definitions })
}

fn parse_vehicle_file(
    bytes: &[u8],
    definitions: &mut BTreeMap<String, VehicleDefinition>,
) -> Result<(), String> {
    let mut parser = ComParser::new(bytes);
    while let Some(name) = parser.token(true)? {
        if name == "{" || name == "}" {
            return Err(format!("unexpected vehicle token {name:?}"));
        }
        let Some(open) = parser.token(true)? else {
            return Err(format!("unexpected EOF after vehicle {name:?}"));
        };
        if open != "{" {
            return Err(format!("vehicle {name:?} missing opening '{{'"));
        }

        let mut model = None;
        let mut skin = None;
        loop {
            let Some(key) = parser.token(true)? else {
                return Err(format!("unexpected EOF while parsing vehicle {name:?}"));
            };
            if key == "}" {
                break;
            }
            match key.to_ascii_lowercase().as_str() {
                "model" => {
                    if let Some(value) = parser.token(false)? {
                        let value = value.replace('\\', "/");
                        if !value.is_empty() {
                            model = Some(value);
                        }
                    }
                }
                "skin" => {
                    if let Some(value) = parser.token(false)? {
                        let value = value.replace('\\', "/");
                        if !value.is_empty() && !value.eq_ignore_ascii_case("default") {
                            skin = Some(value);
                        }
                    }
                }
                _ => parser.skip_rest_of_line(),
            }
        }

        // A malformed or abstract block with no model is not renderable, so it
        // should not shadow a later usable definition of the same name.
        if let Some(model) = model {
            definitions
                .entry(name.to_ascii_lowercase())
                .or_insert_with(|| VehicleDefinition {
                    name,
                    model,
                    skin,
                });
        }
    }
    Ok(())
}

struct ComParser<'a> {
    data: &'a [u8],
    cursor: usize,
}

impl<'a> ComParser<'a> {
    fn new(data: &'a [u8]) -> Self {
        Self { data, cursor: 0 }
    }

    fn token(&mut self, allow_line_breaks: bool) -> Result<Option<String>, String> {
        loop {
            let mut crossed_line = false;
            while self.cursor < self.data.len() && self.data[self.cursor] <= b' ' {
                crossed_line |= self.data[self.cursor] == b'\n';
                self.cursor += 1;
            }
            if crossed_line && !allow_line_breaks {
                return Ok(None);
            }
            if self.cursor >= self.data.len() || self.data[self.cursor] == 0 {
                return Ok(None);
            }
            if self.starts_with(b"//") {
                self.skip_rest_of_line();
                if !allow_line_breaks {
                    return Ok(None);
                }
                continue;
            }
            if self.starts_with(b"/*") {
                self.cursor += 2;
                while self.cursor + 1 < self.data.len() && !self.starts_with(b"*/") {
                    self.cursor += 1;
                }
                if self.cursor + 1 >= self.data.len() {
                    return Err("unterminated block comment in vehicle file".to_owned());
                }
                self.cursor += 2;
                continue;
            }
            break;
        }

        if self.data[self.cursor] == b'"' {
            self.cursor += 1;
            let start = self.cursor;
            while self.cursor < self.data.len()
                && self.data[self.cursor] != b'"'
                && self.data[self.cursor] != 0
            {
                self.cursor += 1;
            }
            if self.cursor >= self.data.len() || self.data[self.cursor] != b'"' {
                return Err("unterminated quoted string in vehicle file".to_owned());
            }
            let token = ascii_token(&self.data[start..self.cursor])?;
            self.cursor += 1;
            return Ok(Some(token));
        }

        if matches!(self.data[self.cursor], b'{' | b'}') {
            let token = (self.data[self.cursor] as char).to_string();
            self.cursor += 1;
            return Ok(Some(token));
        }

        let start = self.cursor;
        while self.cursor < self.data.len()
            && self.data[self.cursor] > b' '
            && !matches!(self.data[self.cursor], b'{' | b'}')
        {
            if self.starts_with(b"//") || self.starts_with(b"/*") {
                break;
            }
            self.cursor += 1;
        }
        if self.cursor == start {
            return Err("empty vehicle token".to_owned());
        }
        Ok(Some(ascii_token(&self.data[start..self.cursor])?))
    }

    fn skip_rest_of_line(&mut self) {
        while self.cursor < self.data.len()
            && self.data[self.cursor] != b'\n'
            && self.data[self.cursor] != 0
        {
            self.cursor += 1;
        }
    }

    fn starts_with(&self, needle: &[u8]) -> bool {
        self.data.get(self.cursor..self.cursor + needle.len()) == Some(needle)
    }
}

fn ascii_token(bytes: &[u8]) -> Result<String, String> {
    if !bytes.is_ascii() {
        return Err("vehicle token is not ASCII".to_owned());
    }
    Ok(String::from_utf8(bytes.to_vec()).expect("ASCII is UTF-8"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_model_and_skin_from_vehicle_blocks() {
        let mut defs = BTreeMap::new();
        parse_vehicle_file(
            br#"
                // Stock-style vehicle definition.
                x-wing {
                    name "X-Wing"
                    type VH_FIGHTER
                    model x-wing
                    skin red
                    speedMax 900
                }
                swoop {
                    model "swoop"
                    skin default
                }
            "#,
            &mut defs,
        )
        .unwrap();

        let xwing = &defs["x-wing"];
        assert_eq!(xwing.model, "x-wing");
        assert_eq!(xwing.skin.as_deref(), Some("red"));
        let swoop = &defs["swoop"];
        assert_eq!(swoop.model, "swoop");
        assert_eq!(swoop.skin, None);
    }

    #[test]
    fn first_definition_wins_like_jka_parameter_loading() {
        let mut defs = BTreeMap::new();
        parse_vehicle_file(b"X-Wing { model first }\nx-wing { model second }\n", &mut defs).unwrap();
        assert_eq!(defs["x-wing"].model, "first");
    }
}
